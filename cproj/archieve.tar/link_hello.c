#include <stdio.h>
int main(void) {
	printf("Hello WOrld!\n");
	printf("Hello WOrld!\n");
	printf("What a wonderful World!~\n");
	return 0;
}
/*
1
2
3
4
5
6
7
8
*/
